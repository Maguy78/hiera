# 🚀 HIERA - Démarrage rapide

## 📦 Vous avez reçu

Un site web complet et professionnel avec:
- ✅ 5 pages interconnectées
- ✅ Design minimaliste élégant
- ✅ 4 images premium intégrées
- ✅ Typographies modernes (DM Serif Display + Manrope)
- ✅ Responsive (mobile, tablette, desktop)
- ✅ Formulaire de contact fonctionnel
- ✅ Blog avec 4 articles complets

---

## 🎯 Démarrer en 3 étapes

### 1. Testez localement (30 secondes)
```
1. Double-cliquez sur "index.html"
2. Votre navigateur s'ouvre avec le site
3. Cliquez sur les liens pour naviguer
```

### 2. Explorez les pages
- **Accueil** — Landing page avec offre principale + image architecture
- **À propos** — Vision, approche, engagement + image arcade
- **Services** — Détails du diagnostic 7j + image escalator
- **Blog** — 4 articles complets + image dôme spiral
- **Contact** — Formulaire simple et efficace

### 3. Personnalisez
Ouvrez les fichiers `.html` avec un éditeur (Notepad, VS Code):
- Remplacez "HIERA" par votre nom
- Modifiez les descriptions
- Changez les couleurs ou polices si besoin

---

## 📁 Structure du dossier

```
hiera-site/
├── index.html                 ← Ouvrez ce fichier d'abord
├── typography-demo.html       ← Voir les polices
├── README.md                  ← Documentation complète
├── IMAGE-INTEGRATION.md       ← Guide des images
├── QUICK-START.md             ← Ce fichier
├── css/
│   └── style.css             ← Tous les styles
├── pages/
│   ├── about.html
│   ├── services.html
│   ├── blog.html
│   └── contact.html
└── assets/
    ├── modern-building.png
    ├── arcade-structure.png
    ├── escalator-ascension.png
    └── dome-spiral.png
```

---

## 🎨 Ce qui rend ce site spécial

### Typographies
- **Titres:** DM Serif Display (élégant, arrondi, intellectuel)
- **Texte:** Manrope (moderne, lisible, fluide)
- **Interligne:** 1.7 (respiration optimale)

### Couleurs
- Blanc pur (#ffffff)
- Noir profond (#1a1a1a)
- Gris neutre (#666666)
- Zéro couleurs flashy

### Images
Chaque image a du **sens**:
1. Bâtiment moderne → Structure hiérarchique
2. Arcade → Cohérence et ordre
3. Escalator → Progression et ascension
4. Dôme spiral → Perspective intellectuelle

---

## ⚡ Modifications rapides

### Changer le titre HIERA
Cherchez "HIERA" dans les fichiers `.html` et remplacez

### Changer les couleurs
Dans `css/style.css`:
- `#1a1a1a` = noir texte
- `#ffffff` = blanc fond
- `#666666` = gris texte secondaire

### Ajouter votre photo
1. Placez votre image dans `assets/`
2. Ajoutez le code HTML:
```html
<img src="assets/votre-image.png" alt="Description" class="section-image">
```

---

## 🌐 Mettre en ligne

### Option 1: Hébergement gratuit (GitHub Pages)
1. Créez un repo GitHub
2. Uploadez le dossier `hiera-site`
3. Activez "Pages" dans les settings
4. Votre site est en ligne !

### Option 2: Hébergement payant (OVH, Ionos, etc.)
1. Connectez-vous à votre FTP
2. Uploadez tout le dossier `hiera-site`
3. Accédez via votre domaine

### Option 3: Netlify (très facile)
1. Glissez-déposez le dossier sur netlify.com
2. Votre site est en ligne en 30 secondes

---

## 📞 Formulaire de contact

**Actuellement:** Affiche un message "Merci !" local

**Pour vraiment recevoir les emails:**
1. Visitez https://formspree.io
2. Créez un compte gratuit
3. Connectez votre formulaire (copier-coller)
4. Vous recevrez les emails dans votre inbox

---

## 🔍 SEO (optionnel)

Pour que Google trouve votre site:
1. Ouvrez `index.html`
2. Modifiez le `<title>` (ce qui apparaît en haut du navigateur)
3. Ajoutez des `<meta description>`
4. Utilisez Google Search Console

---

## 📱 Test responsive

Le site fonctionne sur:
✅ Desktop (1200px+)
✅ Tablette (768-1199px)
✅ Mobile (< 768px)

Testez en redimensionnant votre navigateur (F12 → Toggle device toolbar)

---

## 🎯 Checklist avant mise en ligne

- [ ] Texte personnalisé (remplacé "HIERA")
- [ ] Vérifié tous les liens (fonctionnent-ils ?)
- [ ] Testé le formulaire de contact
- [ ] Testé sur mobile (responsive OK ?)
- [ ] Vérifié les images (s'affichent bien ?)
- [ ] Configuré Formspree (emails fonctionnels ?)
- [ ] Uploadé sur un serveur web

---

## ❓ FAQ rapide

**Q: Les polices ne s'affichent pas?**
R: Videz le cache (Ctrl+Shift+Delete) et rafraîchissez (F5)

**Q: Une image ne s'affiche pas?**
R: Vérifiez que le dossier `assets/` est à côté du `index.html`

**Q: Comment ajouter une page?**
R: Copiez `pages/about.html`, modifiez le contenu, ajoutez un lien

**Q: Le formulaire ne marche pas?**
R: Configurez Formspree.io (gratuit et facile)

**Q: Puis-je changer la couleur du texte?**
R: Oui ! Dans `css/style.css`, cherchez les couleurs et modifiez

---

## 🎁 Ressources utiles

- **Google Fonts:** https://fonts.google.com (changer les polices)
- **Color Picker:** https://htmlcolorcodes.com (choisir des couleurs)
- **Tinypng:** https://tinypng.com (compresser les images)
- **Formspree:** https://formspree.io (formulaires d'email)
- **Netlify:** https://netlify.com (hébergement gratuit)

---

## 🚀 Prochaines étapes

1. ✅ Testez localement
2. ✅ Personnalisez le texte
3. ✅ Testez la navigation
4. ✅ Configurez Formspree (optionnel)
5. ✅ Uploadez sur un serveur
6. ✅ Partagez votre site !

---

## 💡 Conseils finaux

- **Minimalisme:** Gardez le design épuré, ça fonctionne
- **Hiérarchie:** Mettez les infos importantes en premier
- **Clarté:** Écrivez court et lisible
- **Action:** Chaque section doit avoir un CTA (bouton)
- **Images:** Elles renforcent le message, utilisez-les bien

---

## 🎉 C'est prêt!

Votre site est **professionnel**, **moderne** et **prêt à impressionner**.

Les images symbolisent votre message.
Les typographies créent une expérience premium.
Le design parle pour vous.

**Bonne chance! 🚀**

---

*Créé en 2024 | HIERA - Architecture de la Visibilité*
