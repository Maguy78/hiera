# 📸 Images intégrées dans HIERA

## Structure des images

```
hiera-site/
├── assets/
│   ├── modern-building.png      (Bâtiment moderne avec structure)
│   ├── arcade-structure.png     (Arcade avec colonnes)
│   ├── escalator-ascension.png  (Escalator vers le haut)
│   └── dome-spiral.png          (Dôme spiral)
```

---

## Intégration par page

### 1️⃣ Accueil (index.html)
**Image:** `modern-building.png`  
**Emplacement:** Section "Ce que nous analysons" (après les 4 piliers)  
**Légende:** "La structure crée la clarté. L'ordre crée la crédibilité."  
**Symbolique:** Représente la structuration hiérarchique et l'ordre architectural

### 2️⃣ À propos (pages/about.html)
**Image:** `arcade-structure.png`  
**Emplacement:** Section "Notre approche" (après les 4 piliers énumérés)  
**Légende:** "Une structure claire révèle la direction et l'ordre."  
**Symbolique:** Les arcades répétées symbolisent la cohérence et l'ordre systématique

### 3️⃣ Services (pages/services.html)
**Image:** `escalator-ascension.png`  
**Emplacement:** Section "Processus de diagnostic" (après la timeline)  
**Légende:** "Chaque étape vous rapproche de votre objectif stratégique."  
**Symbolique:** L'escalator représente la progression graduelle et l'ascension vers le succès

### 4️⃣ Blog (pages/blog.html)
**Image:** `dome-spiral.png`  
**Emplacement:** Page header (titre de la page)  
**Légende:** (Implicite - pas de légende)  
**Symbolique:** Le dôme spiral crée une impression de profondeur et de perspective intellectuelle

---

## Styles CSS appliqués

### Classes disponibles:
- `.section-image` — Image principale avec hover effect
- `.image-caption` — Légende grise, discrète et italique

### Propriétés:
```css
.section-image {
    width: 100%;
    max-width: 600px;
    height: auto;
    object-fit: cover;
    margin: 2rem auto;
    display: block;
    border: 1px solid #eeeeee;
    transition: all 0.3s ease;
}

.section-image:hover {
    box-shadow: 0 8px 24px rgba(26, 26, 26, 0.12);
}

.image-caption {
    font-size: 0.85rem;
    color: #999999;
    text-align: center;
    margin-top: 1rem;
    font-style: italic;
}
```

---

## 🎨 Stratégie visuelle

### Thème commun: Hiérarchie & Structure
Toutes les images partagent un thème visuel fort:
- **Géométrie** — Structures clairement définies
- **Symétrie** — Ordre et équilibre
- **Perspective** — Profondeur et direction
- **Lumière** — Clarté et visibilité

### Cohérence avec HIERA:
Ces images renforcent le message core:
- La structure crée la clarté
- L'ordre crée la crédibilité
- La hiérarchie guide la perception
- L'architecture numérique se construit

---

## 📱 Responsive

Les images s'adaptent automatiquement:
- **Desktop:** Largeur maximale 600px, centrées
- **Tablette:** Ajustement automatique
- **Mobile:** Largeur 100%, hauteur automatique

Aucune modification de CSS nécessaire, c'est responsif par défaut.

---

## ✨ Effets visuels

### Hover effect
Les images ont un effet shadow subtil au survol:
```
Avant: border simple 1px #eeeeee
Après: box-shadow: 0 8px 24px rgba(26, 26, 26, 0.12)
```

Cela crée une impression de relief et d'interactivité sans surcharger le design.

---

## 🔄 Ajouter d'autres images

Pour ajouter de nouvelles images:

1. **Placez le fichier** dans `/assets/`
2. **Nommez-le clairement** (ex: `image-concept.png`)
3. **Insertez le code HTML:**
```html
<img src="../assets/image-concept.png" alt="Description" class="section-image">
<p class="image-caption">Votre légende ici.</p>
```

4. Les styles CSS s'appliqueront automatiquement !

---

## 📐 Optimisation des images

Les images sont:
- ✅ PNG (meilleure qualité pour les architectures)
- ✅ ~72-149 KB chacune (bon équilibre taille/qualité)
- ✅ Naturelles et authentiques (pas de filtres)
- ✅ Format vertical/portrait (s'adapte bien au web)

**Conseil:** Pour garder le site léger, optimisez avec Tinypng.com si vous ajoutez d'autres images.

---

## 🎯 Impact final

Ces images:
✨ Renforcent le message core de HIERA  
✨ Créent une expérience visuelle premium  
✨ Symbolisent la hiérarchie et l'ordre  
✨ Maintiennent la cohérence minimaliste  
✨ Ajoutent de la profondeur sans surcharge  

**Résultat:** Un site qui montre, ne seulement dit.

---

*Créé en 2024 | HIERA - Architecture de la Visibilité*
