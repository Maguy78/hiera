# 🎨 HIERA - Architecture de la Visibilité

## Site web complet avec 5 pages

### 📋 Structure du projet
```
hiera-site/
├── index.html                 (Accueil)
├── css/
│   └── style.css             (Styles globaux)
└── pages/
    ├── about.html            (À propos)
    ├── services.html         (Services & offres)
    ├── blog.html             (Articles & insights)
    └── contact.html          (Formulaire de contact)
```

---

## 🎯 Typographies utilisées

### Titres et éléments clés
**DM Serif Display** (weight: 400)
- Logo HIERA
- Tous les titres de sections (h1, h2, h3)
- Titres d'articles
- Noms de piliers

Caractéristiques:
- Courbes élégantes et rondes
- Caractère intellectuel
- Non-rigide, très contemporain
- Poids régulier (400) pour une subtilité

### Texte du corps
**Manrope** (weights: 400, 500, 600, 700)
- Paragraphes
- Texte général
- Labels de formulaires
- Contenu du blog

Caractéristiques:
- Sans-serif ronde et moderne
- Courbes douces
- Excellente lisibilité
- Style très contemporain
- Interligne large (1.7) pour une meilleure fluidité

---

## 🎨 Palette de couleurs

| Élément | Couleur | Code |
|---------|---------|------|
| Fond | Blanc pur | #ffffff |
| Texte principal | Noir profond | #1a1a1a |
| Texte secondaire | Gris | #666666 |
| Bordures | Gris très léger | #eeeeee |
| Fond sections | Gris très léger | #fafafa |
| CTA & Footer | Noir très foncé | #0a0a0a, #1a1a1a |

---

## 📄 Pages incluses

### 1. **Accueil (index.html)**
- Section héro avec offre principale
- Le constat stratégique
- Piliers d'analyse (Hiérarchie, Autorité, Cohérence, Fragilités)
- Présentation du diagnostic 7 jours
- Public cible
- Aperçu du blog
- CTA final

### 2. **À propos (pages/about.html)**
- Vision HIERA
- Approche méthodologique
- Les 4 piliers détaillés
- Engagement envers les clients
- Fondatrice (crédit sobre)

### 3. **Services (pages/services.html)**
- Description du diagnostic d'Architecture de Visibilité
- Trois piliers du service (Audit, Cartographie, Recommandations)
- Timeline du processus (7 jours)
- Public cible
- Format du livrable
- Tarification (à personnaliser)

### 4. **Blog (pages/blog.html)**
- 4 articles complets :
  1. La hiérarchie numérique en 2024
  2. Audit de crédibilité : 5 points clés
  3. Cohérence multi-canaux
  4. Fragilités numériques
- Articles avec titles, métadonnées, contenu, tags

### 5. **Contact (pages/contact.html)**
- Formulaire complet avec validation
- Champs : Nom, Entreprise, Email, Téléphone, Contexte, Message
- Message de succès après soumission
- Info de contact

---

## 🚀 Comment utiliser

### En local (directement)
1. Téléchargez le dossier `hiera-site`
2. Ouvrez `index.html` dans votre navigateur
3. Naviguez entre les pages
4. Le formulaire de contact affiche un message de confirmation

### Pour mettre en ligne
1. Uploadez le dossier sur votre hébergeur web
2. Configurez un backend pour traiter les formulaires (optionnel)
3. Le site fonctionne avec HTML/CSS/JavaScript pur (pas de dépendances)

---

## 🎨 Personnalisation

### Modifier les textes
- Ouvrez les fichiers `.html` avec un éditeur de texte
- Modifiez le contenu directement
- Les polices se chargeront depuis Google Fonts

### Modifier la couleur
Cherchez `#1a1a1a` (noir) ou `#ffffff` (blanc) et remplacez par vos codes couleur

### Modifier les polices
Dans `css/style.css`, ligne 1, modifiez l'import Google Fonts:
```css
@import url('https://fonts.googleapis.com/css2?family=...');
```

### Ajouter des pages
1. Créez un nouveau fichier `.html` dans le dossier `pages/`
2. Copiez le template d'une page existante
3. Ajoutez le lien dans la navigation des 5 pages

---

## ✨ Points forts du design

✅ **Minimalisme élégant** — Blanc pur, noir profond, zéro décoration inutile  
✅ **Typographies rondes** — Donne une sensation humaine et contemporaine  
✅ **Responsive** — Fonctionne parfaitement sur mobile, tablette, desktop  
✅ **Navigation fluide** — Transitions douces, interactive sans surcharge  
✅ **Hiérarchie visuelle claire** — Les informations importantes ressortent naturellement  
✅ **Accessible** — Bonnes contrastes, textes lisibles, navigation intuitive  
✅ **Performance** — Léger, aucune dépendance externe (sauf Google Fonts)  

---

## 🔧 Améliorations possibles

### Backend pour le formulaire de contact
Actuellement, le formulaire affiche juste un message local. Pour vraiment envoyer les données :
- **Option 1** : Utiliser Formspree.io (gratuit, intégration facile)
- **Option 2** : Configurer un serveur PHP/Node.js simple
- **Option 3** : Intégrer avec Mailchimp, HubSpot, ou autre CRM

### Analytics
Ajouter Google Analytics ou Plausible pour tracker les visiteurs

### Blog dynamique
Transformer le blog en CMS (Contentful, Sanity, ou simple backend JSON)

### Chatbot
Ajouter un chatbot de contact pour les demandes immédates

---

## 📞 Support

Pour toute question sur la structure ou les styles, consultez les fichiers CSS directement — ils sont largement commentés et auto-explicatifs.

---

**Créé en 2024 | HIERA Architecture de la Visibilité**
